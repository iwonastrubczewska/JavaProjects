CREATE TRIGGER TRG_ACCOUNT_ID
  BEFORE INSERT
  ON ACCOUNT
  FOR EACH ROW
  begin
    select account_id.nextval
    into :new.id
    from dual;
  end;
/

